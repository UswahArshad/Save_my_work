# pythonkachilla_version2
This repository contains materials and files for Python ka chilla version 2.0 (version means course ka version not of python).
This is an advance course led by Dr Aammar Tufail (Python for Data Science in Urdu language)
## youtube channel: [Codanics](https://www.youtube.com/c/Codanics)

### Playlist for this course [Click here](https://youtube.com/playlist?list=PL9XvIvvVL50EyRNp6fnYwMve1CJqJCHj8)

![Poster](00_sources/poster1.png)